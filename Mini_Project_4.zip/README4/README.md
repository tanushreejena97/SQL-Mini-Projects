# Mini Project 4 – SQL JOINs

## Objective
Connect information stored across multiple tables and use it to answer business questions.

## Skills Covered
- INNER JOIN
- LEFT JOIN
- RIGHT JOIN
- SELF JOIN
- CROSS JOIN
- Multiple-table JOINs
- Aggregation with JOINs
- Filtering joined data

## Tasks Covered
- Customer and payment analysis
- Employee and office analysis
- Order and product analysis
- Sales representative analysis
- Employee-manager relationships using a SELF JOIN
- Identifying customers without orders
- Identifying products that have never been sold
- Finding records without matching relationships

## Tools Used
- MySQL
- GitHub

## Files
- `Mini_Project_4.sql` – SQL JOIN queries
- `screenshots/` – Output screenshots

## Observations
Add 3–5 observations based on the results produced by your SQL queries.
