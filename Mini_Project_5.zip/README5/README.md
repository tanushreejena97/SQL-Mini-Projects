# Mini Project 5 – Advanced SQL: Window Functions

## Objective
Use advanced SQL techniques to perform ranking, running-total, comparison, and time-based analysis.

## Skills Covered
- Window functions
- ROW_NUMBER(), RANK(), and DENSE_RANK()
- PARTITION BY and ORDER BY
- SUM() OVER()
- LAG()
- Running totals
- Moving averages
- Common Table Expressions (CTEs)

## Tasks Covered
- Ranking products within product lines
- Identifying the highest-ranked products within product lines
- Calculating cumulative payment values
- Comparing monthly values
- Analysing changes and growth between periods
- Calculating a three-month moving average

## Tools Used
- MySQL
- GitHub

## Files
- `Mini_Project_5.sql` – Advanced SQL queries
- `screenshots/` – Output screenshots
