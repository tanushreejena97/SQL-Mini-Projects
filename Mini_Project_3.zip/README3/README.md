# Mini Project 3 – Data Cleaning & Transformation

## Objective
Work with incomplete or inconsistent data and use SQL to clean and transform it.

## Skills Covered
- NULL handling
- Data cleaning and transformation
- String manipulation
- Duplicate detection
- UPDATE statements
- Conditional logic
- Data standardisation

## Tasks Covered
- Identifying and handling missing values
- Trimming and standardising customer names
- Cleaning email and phone-number fields
- Detecting duplicate records
- Analysing order statuses
- Extracting information from product codes
- Identifying inconsistent data
- Standardising city and status values

## Tools Used
- MySQL
- GitHub

## Files
- `Mini_Project_3.sql` – SQL statements for data cleaning and transformation
- `screenshots/` – Output screenshots
