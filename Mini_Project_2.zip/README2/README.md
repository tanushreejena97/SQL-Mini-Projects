# Mini Project 2 – ClassicModels Query Challenge

## Objective
Use SQL queries to explore business data and answer customer, product, and payment questions.

## Skills Covered
- SELECT and WHERE
- ORDER BY
- GROUP BY and HAVING
- LIKE and IN
- LIMIT and OFFSET
- Aggregate functions such as COUNT, SUM, AVG, MIN, and MAX
- Subqueries

## Tasks Covered
- Customer location and credit-limit analysis
- Searching and sorting customer records
- Product price, product-line, and stock analysis
- Payment dates and payment activity
- Total, average, minimum, and maximum payment calculations
- Subqueries for comparing values and identifying records

## Tools Used
- MySQL
- GitHub

## Files
- `Mini_Project_2.sql` – SQL queries for the project
- `screenshots/` – Output screenshots

## Note
If the assignment requires the original ClassicModels database, use its supplied dataset. Sample data should be identified as sample data and is not a substitute for the original dataset.
