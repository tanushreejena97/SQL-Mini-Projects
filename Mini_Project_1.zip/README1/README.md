# Mini Project 1 – SQL Foundations & Database Operations

## Objective
Build a foundation in SQL by creating and manipulating databases and tables.

## Skills Covered
- Database and table creation
- DDL and DML commands
- INSERT, UPDATE, and DELETE
- ALTER TABLE
- Modifying table structures and renaming columns
- CASE statements and conditional logic

## Tasks Completed
- Created a database and table
- Inserted sample student records
- Added and renamed a column
- Updated and deleted records
- Used CASE expressions to classify performance and age

## Tools Used
- MySQL
- GitHub

## Files
- `Mini_Project_1.sql` – SQL commands for the project
- `screenshots/` – Output screenshots
